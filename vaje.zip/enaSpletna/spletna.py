from bottle import *
import models

@route('/')
def index():
    return template('prva')


@route('/iskanje2')
def iskanje():
    return template('iskanje2')
    
run(reloder = True, debug = True)