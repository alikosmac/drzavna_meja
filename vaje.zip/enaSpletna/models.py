def vsota(x, y):
    return x+y