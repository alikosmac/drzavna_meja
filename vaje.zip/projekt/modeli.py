import sqlite3

con = sqlite3.connect("meja16.sqlite")


############TUKAJ SO ČISTO OSNOVNE POIZVEDBE, KI VRACAJO PRIMARNE KLJUCE ZA RAZLICNE STVARI############
def isciOsebe(ime = None, priimek = None, spol = None, naslov = None, datum_rojstva = None, datum_rojstvaOP = '='):
    sql = """SELECT oseba.id FROM oseba WHERE """
    pogoji = [] #tukaj shranjujemo ustrezne pogoje, ki jih bomo kasneje porabili v SQL stavku

    if ime == None:
        pogoji.append("oseba.ime LIKE '%'")
    else:
        pogoji.append("oseba.ime LIKE '{0}'".format(ime))
    
    if priimek == None:
        pogoji.append("oseba.priimek LIKE '%'")
    else:
        pogoji.append("oseba.priimek LIKE '{0}'".format(priimek))
    
    if spol == None:
        pogoji.append("oseba.spol LIKE '%'")
    else:
        pogoji.append("oseba.spol LIKE '{0}'".format(spol))
    
    if naslov == None:
        pogoji.append("oseba.naslov LIKE '%'")
    else:
        pogoji.append("oseba.naslov LIKE '{0}'".format(naslov))
    
    if datum_rojstva == None:
        pogoji.append("oseba.datum_rojstva LIKE '%'")
    else:
        pogoji.append("oseba.datum_rojstva {0} '{1}'".format(datum_rojstvaOP, datum_rojstva))
    
    sql += " AND ".join(pogoji)

    return [ _[0] for _ in con.execute(sql)]


def isciDokumente(oseba = None, tip = None, datum_izdaje = None, datum_poteka = None, drzava = None, datum_izdajeOP = '=', datum_potekaOP = '='):
    sql = """SELECT dokument.st_dokumenta FROM dokument WHERE """
    pogoji = [] #tukaj shranjujemo ustrezne pogoje, ki jih bomo kasneje porabili v SQL stavku

    if oseba == None:
        pogoji.append("dokument.oseba LIKE '%'")
    else:
        pogoji.append("dokument.oseba LIKE '{0}'".format(oseba))
    
    if tip == None:
        pogoji.append("dokument.tip LIKE '%'")
    else:
        pogoji.append("dokument.tip LIKE '{0}'".format(tip))
    
    if datum_izdaje == None:
        pogoji.append("dokument.datum_izdaje LIKE '%'")
    else:
        pogoji.append("dokument.datum_izdaje {0} '{1}'".format(datum_izdajeOP, datum_izdaje))
    
    if datum_poteka == None:
        pogoji.append("dokument.datum_poteka LIKE '%'")
    else:
        pogoji.append("dokument.datum_poteka {0} '{1}'".format(datum_potekaOP, datum_poteka))

    if drzava == None:
        pogoji.append("dokument.drzava LIKE '%'")
    else:
        pogoji.append("dokument.drzava LIKE '{0}'".format(drzava))
    
    sql += " AND ".join(pogoji)
    return [ _[0] for _ in con.execute(sql)]


def isciVize(dokument = None, tip = None, datum_izdaje = None, datum_poteka = None, datum_izdajeOP = '=', datum_potekaOP = '='):
    sql = """SELECT vizum.id FROM vizum WHERE """
    pogoji = [] #tukaj shranjujemo ustrezne pogoje, ki jih bomo kasneje porabili v SQL stavku

    if dokument == None:
        pogoji.append("vizum.dokument LIKE '%'")
    else:
        pogoji.append("vizum.dokument LIKE '{0}'".format(dokument))
    
    if tip == None:
        pogoji.append("vizum.tip LIKE '%'")
    else:
        pogoji.append("vizum.tip LIKE '{0}'".format(tip))
    
    if datum_izdaje == None:
        pogoji.append("vizum.datum_izdaje LIKE '%'")
    else:
        pogoji.append("vizum.datum_izdaje {0} '{1}'".format(datum_izdajeOP, datum_izdaje))
    
    if datum_poteka == None:
        pogoji.append("vizum.datum_poteka LIKE '%'")
    else:
        pogoji.append("vizum.datum_poteka {0} '{1}'".format(datum_potekaOP, datum_poteka))
    
    sql += " AND ".join(pogoji)

    return [ _[0] for _ in con.execute(sql)]

def isciPrestope(dokument = None, namen = None, mejni_prehod = None, datum = None, datumOP = '='):
    sql = """SELECT prestop.id FROM prestop WHERE """
    pogoji = [] #tukaj shranjujemo ustrezne pogoje, ki jih bomo kasneje porabili v SQL stavku

    if dokument == None:
        pogoji.append("prestop.dokument LIKE '%'")
    else:
        pogoji.append("prestop.dokument LIKE '{0}'".format(dokument))
    
    if namen == None:
        pogoji.append("prestop.namen LIKE '%'")
    else:
        pogoji.append("prestop.namen LIKE '{0}'".format(namen))
    
    if mejni_prehod == None:
        pogoji.append("prestop.mejni_prehod LIKE '%'")
    else:
        pogoji.append("prestop.mejni_prehod LIKE '{0}'".format(mejni_prehod))
    
    if datum == None:
        pogoji.append("prestop.datum LIKE '%'")
    else:
        pogoji.append("prestop.datum LIKE {0} '{0}'".format(datumOP, datum))
    
    sql += " AND ".join(pogoji)

    return [ _[0] for _ in con.execute(sql)]

def isciOSEBA_DOKUMENT(ime = None, priimek = None, spol = None, naslov = None, datum_rojstva = None, datum_rojstvaOP = '=', 
                      oseba = None, tip = None, datum_izdaje = None, datum_poteka = None, drzava = None, datum_izdajeOP = '=', datum_potekaOP = '='):
                      sql = """SELECT *
                                FROM oseba JOIN dokument ON oseba.id = dokument.oseba JOIN drzava ON dokument.drzava = drzava.kratica
                                WHERE """
                      pogoji = []
                      if ime == None:
                        pogoji.append("oseba.ime LIKE '%'")
                      else:
                        pogoji.append("oseba.ime LIKE '{0}'".format(ime))
                        
                      if priimek == None:
                        pogoji.append("oseba.priimek LIKE '%'")
                      else:
                        pogoji.append("oseba.priimek LIKE '{0}'".format(priimek))
                        
                      if spol == None:
                        pogoji.append("oseba.spol LIKE '%'")
                      else:
                        pogoji.append("oseba.spol LIKE '{0}'".format(spol))
                        
                      if naslov == None:
                        pogoji.append("oseba.naslov LIKE '%'")
                      else:
                        pogoji.append("oseba.naslov LIKE '{0}'".format(naslov))
                        
                      if datum_rojstva == None:
                        pogoji.append("oseba.datum_rojstva LIKE '%'")
                      else:
                        pogoji.append("oseba.datum_rojstva {0} '{1}'".format(datum_rojstvaOP, datum_rojstva))

                      if oseba == None:
                        pogoji.append("dokument.oseba LIKE '%'")
                      else:
                        pogoji.append("dokument.oseba LIKE '{0}'".format(oseba))
                        
                      if tip == None:
                        pogoji.append("dokument.tip LIKE '%'")
                      else:
                        pogoji.append("dokument.tip LIKE '{0}'".format(tip))
                        
                      if datum_izdaje == None:
                        pogoji.append("dokument.datum_izdaje LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_izdaje {0} '{1}'".format(datum_izdajeOP, datum_izdaje))
                        
                      if datum_poteka == None:
                        pogoji.append("dokument.datum_poteka LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_poteka {0} '{1}'".format(datum_potekaOP, datum_poteka))

                      if drzava == None:
                        pogoji.append("dokument.drzava LIKE '%'")
                      else:
                        pogoji.append("dokument.drzava IN {0}".format(tuple(drzava)))

                      sql += " AND ".join(pogoji)
                      return [ _[0] for _ in con.execute(sql)]

def isciOSEBA_DOKUMENT_VIZUM(ime = None, priimek = None, spol = None, naslov = None, datum_rojstva = None, datum_rojstvaOP = '=', 
                      oseba = None, tip = None, datum_izdaje = None, datum_poteka = None, drzava = None, datum_izdajeOP = '=', datum_potekaOP = '=',
                      dokument = None,tipV = None, datum_izdajeV = None, datum_potekaV = None, datum_izdajeVOP = '=', datum_potekaVOP = '='):
                      sql = """SELECT *
                                FROM oseba JOIN dokument ON oseba.id = dokument.oseba JOIN vizum on dokument.st_dokumenta = vizum.dokument
                                WHERE """
                      pogoji = []
                      if ime == None:
                        pogoji.append("oseba.ime LIKE '%'")
                      else:
                        pogoji.append("oseba.ime LIKE '{0}'".format(ime))
                        
                      if priimek == None:
                        pogoji.append("oseba.priimek LIKE '%'")
                      else:
                        pogoji.append("oseba.priimek LIKE '{0}'".format(priimek))
                        
                      if spol == None:
                        pogoji.append("oseba.spol LIKE '%'")
                      else:
                        pogoji.append("oseba.spol LIKE '{0}'".format(spol))
                        
                      if naslov == None:
                        pogoji.append("oseba.naslov LIKE '%'")
                      else:
                        pogoji.append("oseba.naslov LIKE '{0}'".format(naslov))
                        
                      if datum_rojstva == None:
                        pogoji.append("oseba.datum_rojstva LIKE '%'")
                      else:
                        pogoji.append("oseba.datum_rojstva {0} '{1}'".format(datum_rojstvaOP, datum_rojstva))

                      if oseba == None:
                        pogoji.append("dokument.oseba LIKE '%'")
                      else:
                        pogoji.append("dokument.oseba LIKE '{0}'".format(oseba))
                        
                      if tip == None:
                        pogoji.append("dokument.tip LIKE '%'")
                      else:
                        pogoji.append("dokument.tip LIKE '{0}'".format(tip))
                        
                      if datum_izdaje == None:
                        pogoji.append("dokument.datum_izdaje LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_izdaje {0} '{1}'".format(datum_izdajeOP, datum_izdaje))
                        
                      if datum_poteka == None:
                        pogoji.append("dokument.datum_poteka LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_poteka {0} '{1}'".format(datum_potekaOP, datum_poteka))

                      if drzava == None:
                        pogoji.append("dokument.drzava LIKE '%'")
                      else:
                        pogoji.append("dokument.drzava IN {0}".format(tuple(drzava)))

                      if dokument == None:
                        pogoji.append("vizum.dokument LIKE '%'")
                      else:
                        pogoji.append("vizum.dokument LIKE '{0}'".format(dokument))
                    
                      if tipV == None:
                        pogoji.append("vizum.tip LIKE '%'")
                      else:
                        pogoji.append("vizum.tip LIKE '{0}'".format(tipV))
                    
                      if datum_izdajeV == None:
                        pogoji.append("vizum.datum_izdaje LIKE '%'")
                      else:
                        pogoji.append("vizum.datum_izdaje {0} '{1}'".format(datum_izdajeVOP, datum_izdajeV))
                    
                      if datum_potekaV == None:
                        pogoji.append("vizum.datum_poteka LIKE '%'")
                      else:
                        pogoji.append("vizum.datum_poteka {0} '{1}'".format(datum_potekaVOP, datum_potekaV))

                      sql += " AND ".join(pogoji)

                      return [ _[0] for _ in con.execute(sql)]               


def isciOSEBA_DOKUMENT_PRESTOP(ime = None, priimek = None, spol = None, naslov = None, datum_rojstva = None, datum_rojstvaOP = '=', 
                      oseba = None, tip = None, datum_izdaje = None, datum_poteka = None, drzava = None, datum_izdajeOP = '=', datum_potekaOP = '=',
                      dokument = None, namen = None, mejni_prehod = None, datum = None, datumOP = '='):
                      sql = """SELECT *
                                FROM oseba JOIN dokument ON oseba.id = dokument.oseba JOIN prestop on dokument.st_dokumenta = prestop.dokument
                                WHERE """
                      pogoji = []
                      if ime == None:
                        pogoji.append("oseba.ime LIKE '%'")
                      else:
                        pogoji.append("oseba.ime LIKE '{0}'".format(ime))
                        
                      if priimek == None:
                        pogoji.append("oseba.priimek LIKE '%'")
                      else:
                        pogoji.append("oseba.priimek LIKE '{0}'".format(priimek))
                        
                      if spol == None:
                        pogoji.append("oseba.spol LIKE '%'")
                      else:
                        pogoji.append("oseba.spol LIKE '{0}'".format(spol))
                        
                      if naslov == None:
                        pogoji.append("oseba.naslov LIKE '%'")
                      else:
                        pogoji.append("oseba.naslov LIKE '{0}'".format(naslov))
                        
                      if datum_rojstva == None:
                        pogoji.append("oseba.datum_rojstva LIKE '%'")
                      else:
                        pogoji.append("oseba.datum_rojstva {0} '{1}'".format(datum_rojstvaOP, datum_rojstva))

                      if oseba == None:
                        pogoji.append("dokument.oseba LIKE '%'")
                      else:
                        pogoji.append("dokument.oseba LIKE '{0}'".format(oseba))
                        
                      if tip == None:
                        pogoji.append("dokument.tip LIKE '%'")
                      else:
                        pogoji.append("dokument.tip LIKE '{0}'".format(tip))
                        
                      if datum_izdaje == None:
                        pogoji.append("dokument.datum_izdaje LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_izdaje {0} '{1}'".format(datum_izdajeOP, datum_izdaje))
                        
                      if datum_poteka == None:
                        pogoji.append("dokument.datum_poteka LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_poteka {0} '{1}'".format(datum_potekaOP, datum_poteka))

                      if drzava == None:
                        pogoji.append("dokument.drzava LIKE '%'")
                      else:
                        pogoji.append("dokument.drzava IN {0}".format(tuple(drzava)))
                    
                      if dokument == None:
                        pogoji.append("prestop.dokument LIKE '%'")
                      else:
                        pogoji.append("prestop.dokument LIKE '{0}'".format(dokument))
                    
                      if namen == None:
                        pogoji.append("prestop.namen LIKE '%'")
                      else:
                        pogoji.append("prestop.namen LIKE '{0}'".format(namen))
                    
                      if mejni_prehod == None:
                        pogoji.append("prestop.mejni_prehod LIKE '%'")
                      else:
                        pogoji.append("prestop.mejni_prehod LIKE '{0}'".format(mejni_prehod))
                    
                      if datum == None:
                        pogoji.append("prestop.datum LIKE '%'")
                      else:
                        pogoji.append("prestop.datum LIKE {0} '{0}'".format(datumOP, datum))
                    
                      sql += " AND ".join(pogoji)

                      return [ _[0] for _ in con.execute(sql)]

def isciOSEBA_DOKUMENT_VIZUM_PRESTOP(ime = None, priimek = None, spol = None, naslov = None, datum_rojstva = None, datum_rojstvaOP = '=', 
                      oseba = None, tipD = None, datum_izdajeD = None, datum_potekaD = None, drzava = None, datum_izdajeDOP = '=', datum_potekaDOP = '=',
                      dokument = None, namen = None, mejni_prehod = None, datum = None, datumOP = '=',
                      dokumentV = None, tipV = None, datum_izdajeV = None, datum_potekaV = None, datum_izdajeVOP = '=', datum_potekaVOP = '='):
                      sql = """SELECT *
                                FROM oseba JOIN dokument ON oseba.id = dokument.oseba 
                                JOIN prestop on dokument.st_dokumenta = prestop.dokument
                                JOIN vizum on dokument.st_dokumenta = vizum.dokument
                                WHERE """
                      pogoji = []
                      if ime == None:
                        pogoji.append("oseba.ime LIKE '%'")
                      else:
                        pogoji.append("oseba.ime LIKE '{0}'".format(ime))
                        
                      if priimek == None:
                        pogoji.append("oseba.priimek LIKE '%'")
                      else:
                        pogoji.append("oseba.priimek LIKE '{0}'".format(priimek))
                        
                      if spol == None:
                        pogoji.append("oseba.spol LIKE '%'")
                      else:
                        pogoji.append("oseba.spol LIKE '{0}'".format(spol))
                        
                      if naslov == None:
                        pogoji.append("oseba.naslov LIKE '%'")
                      else:
                        pogoji.append("oseba.naslov LIKE '{0}'".format(naslov))
                        
                      if datum_rojstva == None:
                        pogoji.append("oseba.datum_rojstva LIKE '%'")
                      else:
                        pogoji.append("oseba.datum_rojstva {0} '{1}'".format(datum_rojstvaOP, datum_rojstva))

                      if oseba == None:
                        pogoji.append("dokument.oseba LIKE '%'")
                      else:
                        pogoji.append("dokument.oseba LIKE '{0}'".format(oseba))
                        
                      if tipD == None:
                        pogoji.append("dokument.tip LIKE '%'")
                      else:
                        pogoji.append("dokument.tip LIKE '{0}'".format(tipD))
                        
                      if datum_izdajeD == None:
                        pogoji.append("dokument.datum_izdaje LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_izdaje {0} '{1}'".format(datum_izdajeDOP, datum_izdajeD))
                        
                      if datum_potekaD == None:
                        pogoji.append("dokument.datum_poteka LIKE '%'")
                      else:
                        pogoji.append("dokument.datum_poteka {0} '{1}'".format(datum_potekaDOP, datum_potekaD))

                      if drzava == None:
                        pogoji.append("dokument.drzava LIKE '%'")
                      else:
                        pogoji.append("dokument.drzava IN {0}".format(tuple(drzava)))
                    
                      if dokument == None:
                        pogoji.append("prestop.dokument LIKE '%'")
                      else:
                        pogoji.append("prestop.dokument LIKE '{0}'".format(dokument))
                    
                      if namen == None:
                        pogoji.append("prestop.namen LIKE '%'")
                      else:
                        pogoji.append("prestop.namen LIKE '{0}'".format(namen))
                    
                      if mejni_prehod == None:
                        pogoji.append("prestop.mejni_prehod LIKE '%'")
                      else:
                        pogoji.append("prestop.mejni_prehod LIKE '{0}'".format(mejni_prehod))
                    
                      if datum == None:
                        pogoji.append("prestop.datum LIKE '%'")
                      else:
                        pogoji.append("prestop.datum LIKE {0} '{0}'".format(datumOP, datum))

                      if dokumentV == None:
                        pogoji.append("vizum.dokument LIKE '%'")
                      else:
                        pogoji.append("vizum.dokument LIKE '{0}'".format(dokumentV))
                    
                      if tipV == None:
                        pogoji.append("vizum.tip LIKE '%'")
                      else:
                        pogoji.append("vizum.tip LIKE '{0}'".format(tipV))
                    
                      if datum_izdajeV == None:
                        pogoji.append("vizum.datum_izdaje LIKE '%'")
                      else:
                        pogoji.append("vizum.datum_izdaje {0} '{1}'".format(datum_izdajeVOP, datum_izdajeV))
                    
                      if datum_potekaV == None:
                        pogoji.append("vizum.datum_poteka LIKE '%'")
                      else:
                        pogoji.append("vizum.datum_poteka {0} '{1}'".format(datum_potekaVOP, datum_potekaV))

                      sql += " AND ".join(pogoji)

                      return [ _[0] for _ in con.execute(sql)]
########################################################################################################

###################TUKAJ SO FUNKCIJE, KI IZPISUJEJO PODATKE GLEDE NA UNIKATNI PRIMARNI KLJUC###########

def izpisiPodatkeoOsebi(stevilke):
    """ Izpise vse podatke o osebi podani z določenim ID-jem """
    osebe = []
    for stevilka in stevilke:
        stavek = con.execute("""SELECT *
                                FROM oseba
                                WHERE oseba.id = ?; """, [stevilka])
        for _ in stavek:
            osebe.append(_)

    return osebe

def izpisiPodatkeoDokumentu(stevila):
    """ Izpise vse podatke o osebi podani z določenim ID-jem """
    dokumenti = []
    for dokument in stevila:
        stavek = con.execute("""SELECT *
                                FROM dokument
                                WHERE dokument.st_dokumenta = ?; """, [dokument])
        for _ in stavek:
            dokumenti.append(_)

    return dokumenti

def izpisiPodatkeoVizi(stevila):
    """ Izpise vse podatke o osebi podani z določenim ID-jem """
    vize = []
    for vizum in stevila:
        stavek = con.execute("""SELECT *
                                FROM vizum
                                WHERE vizum.id = ?; """, [vizum])
        for _ in stavek:
            vize.append(_)

    return vize

def prikazPodatkov(idOseb):
    """Vrne podatke, ki jih želimo izpisati:
    ime, priimek, naslov, država, datum_rojstva, st_dokumenta"""
    osebe = []
    sql = """ SELECT oseba.ime,
                oseba.priimek,
                oseba.naslov,
                drzava.naziv,
                oseba.datum_rojstva,
                oseba.spol,
                dokument.st_dokumenta
            FROM oseba
                JOIN
                dokument ON oseba.id = dokument.oseba
                JOIN
                drzava on dokument.drzava = drzava.kratica
            WHERE oseba.id IN {0};
            """.format(tuple(idOseb))
    
    for oseba in con.execute(sql):
        osebe.append(oseba)
    return osebe


########################################################################################################
def blackList():
    """Vrne vse tiste stevilke oseb, ki so v državi, ampak ne bi smeli biti """
    osebe = set()
    #Najprej preverimo tiste, ki so jim potekli dokumenti ali pa so lažni,
    #kar pomeni, da začnejo veljati šele po vstopu
    sql1 = """SELECT oseba.id
                FROM oseba
                    JOIN
                    dokument ON oseba.id = dokument.oseba
                    JOIN
                    prestop ON dokument.st_dokumenta = prestop.dokument
                WHERE dokument.datum_poteka < prestop.datum OR 
                    dokument.datum_izdaje > prestop.datum; """
    for st in con.execute(sql1):
        osebe.add(st[0])
    
    #Zdaj preverimo še tiste, ki nimajo veljavne vize 
    #bodi si jim je potekla pred dokumentom
    #ali pa jim je potekla ko so hoteli prestopiti

    sql2 = """ SELECT oseba.id
                FROM oseba
                    JOIN
                    dokument ON oseba.id = dokument.oseba
                    JOIN
                    vizum ON dokument.st_dokumenta = vizum.dokument
                    JOIN
                    prestop ON dokument.st_dokumenta = prestop.dokument
                WHERE vizum.datum_poteka < dokument.datum_poteka OR 
                    vizum.datum_izdaje > dokument.datum_izdaje OR 
                    vizum.datum_poteka < prestop.datum OR 
                    vizum.datum_izdaje > prestop.datum;"""
    for st in con.execute(sql2):
        osebe.add(st[0])
    
    return list(osebe)
########################################################################################################

#########################FUNKCIJE ZA DODAJANJE V BAZO##################################################
def dodajOsebo(ime, priimek, spol, naslov = None, datum_rojstva = None):
  sql = "INSERT INTO oseba (ime, priimek, spol, naslov, datum_rojstva) VALUES (?, ?, ?, ?, ?)"
  con.execute(sql, (ime, priimek, spol, naslov, datum_rojstva))

def dodajDokument(st_dokumenta, oseba, tip, datum_izdaje, datum_poteka, drzava):
  vsiDokumenti = isciDokumente()
  if st_dokumenta in vsiDokumenti:
    raise Exception("Ta dokument je že v bazi podatkov!")
  elif datum_izdaje > datum_poteka:
    raise Exception("S tem dokumentom nekaj ni vredu!")
  else:
    sql = "INSERT INTO dokument (st_dokumenta, oseba, tip, datum_izdaje, datum_poteka, drzava) VALUES (?, ?, ?, ?, ?, ?)"
    con.execute(sql, (st_dokumenta, oseba, tip, datum_izdaje, datum_poteka, drzava))

def dodajVizum(dokument, tip, datum_izdaje, datum_poteka):
  vsiDokumenti = isciDokumente()
  if dokument not in vsiDokumenti:
    raise Exception("Brez dokumenta ne bo vize!")
  podatkiDokumenta = con.execute("SELECT dokument.datum_izdaje, dokument.datum_poteka FROM dokument WHERE dokument.st_dokumenta = ?", [dokument])
  datumiDok = [] #datum izdaje in datum poteka dokumenta
  datumiDok = list(podatkiDokumenta)
  dokIzdaja = datumiDok[0][0]
  dokPotek = datumiDok[0][1]

  if datum_izdaje < dokIzdaja and datum_izdaje < dokPotek and datum_poteka > dokIzdaja and datum_poteka > dokPotek:
    sql = "INSERT INTO vizum (dokument, tip, datum_izdaje, datum_poteka) VALUES (?, ?, ?, ?)"
    con.execute(sql, (dokument, tip, datum_izdaje, datum_poteka))
  else:
    raise Exception("Dokumenti niso veljavni!")

def dodajPrestop(dokument, namen, mejni_prehod, datum):
  vsiDokumenti = isciDokumente()
  if dokument not in vsiDokumenti:
    raise Exception("Dokument ne obstaja")
  
  podatkiDokumenta = con.execute("SELECT dokument.datum_izdaje, dokument.datum_poteka FROM dokument WHERE dokument.st_dokumenta = ?", [dokument])
  datumiDok = [] #datum izdaje in datum poteka dokumenta
  datumiDok = list(podatkiDokumenta)
  dokIzdaja = datumiDok[0][0]
  dokPotek = datumiDok[0][1]

  if datum < dokPotek:
    sql = "INSERT INTO prestop (dokument, namen, mejni_prehod, datum) VALUES (?, ?, ?, ?)"
    con.execute(sql, (dokument, namen, mejni_prehod, datum))
  else:
    raise Exception("Dokumenti niso veljavni!")



########################################################################################################

dodajPrestop(dokument = "SV00000000", namen = "Vrnitev domov", mejni_prehod = 0, datum = "2016-19-12")


con.commit()