import sqlite3

con = sqlite3.connect("meja16.sqlite")

def isci_parametri(osebaID = None, ime = None, priimek = None, spol = None, naslov = None, datumRojstva = None, datumRojstvaOP = "=",
                    st_dokumenta = None, tipDokumenta = None, datumIzdajeDokument = None, datumPotekaDokument = None, datumIzdajeDokumentOP = None, datumPotekaDokumentOP = None, kraticaDrzave = None,
                    potrebnaViza = False, vizaID = None, tipVize = None, datumIzdajeViza = None, datumPotekaViza = None, datumIzdajeVizaOP = "=", datumPotekaVizaOP = "=",
                    prestopID = None, namen = None, mejniPrehod = None, datumPrestopa = None, datumPrestopaOP = "="):
                    """ Funkcija sprejme določene paramtere in na to glede na te vrne podatke, ki jih iščemo. Lahko se odločimo, da bomo vizo imeli, ali pa ne """
                    osebe = [] #Funkcija vrača le ID-je oseb, ki jih iščemo
                    #najprej zgradimo osnovni sql stavek, ki mu postopoma dodajamo pogoje v WHERE ali FROM stavku
                    sql = ""
                    pogoji = [] #Tu bomo dodajali pogoje, ki jih kasneje nalepimo, na naš sql stavek
                    if potrebnaViza == False:
                        sql = """SELECT oseba.id
                                FROM oseba
                                    JOIN
                                    dokument ON oseba.id = dokument.oseba
                                    JOIN
                                    prestop ON dokument.st_dokumenta = prestop.dokument
                                    WHERE """
                    else:
                        sql = """SELECT oseba.id
                                FROM oseba
                                    JOIN
                                    dokument ON oseba.id = dokument.oseba
                                    JOIN
                                    prestop ON dokument.st_dokumenta = prestop.dokument
                                    JOIN
                                    vizum ON dokument.st_dokumenta = vizum.dokument
                                    WHERE """
                    #Kar se tiče osebe
                    
                    if osebaID == None:
                        pogoji.append(" oseba.id LIKE '%' ")
                    else:
                        pogoji.append(" oseba.id LIKE '{0}' ".format(osebaID))
                    
                    if ime == None:
                        pogoji.append(" oseba.ime LIKE '%' ")
                    else:
                        pogoji.append(" oseba.ime LIKE '{0}' ".format(ime))
                    
                    if priimek == None:
                        pogoji.append(" oseba.priimek LIKE '%' ")
                    else:
                        pogoji.append(" oseba.priimek LIKE '{0}' ".format(priimek))
                    
                    if spol == None:
                        pogoji.append(" oseba.spol LIKE '%' ")
                    else:
                        pogoji.append(" oseba.spol LIKE '{0}' ".format(spol))
                    
                    if naslov == None:
                        pogoji.append(" oseba.naslov LIKE '%' ")
                    else:
                        pogoji.append(" oseba.naslov LIKE '{0}' ".format(naslov))
                    
                    if datumRojstva == None:
                        pogoji.append(" oseba.datum_rojstva LIKE '%' ")
                    else:
                        pogoji.append(" oseba.datum_rojstva {0} '{1}' ".format(datumRojstvaOP, datumRojstva))
                    
                    #Kar se tiče dokumenta

                    if st_dokumenta == None:
                        pogoji.append(" dokument.st_dokumenta LIKE '%' ")
                    else:
                        pogoji.append(" dokument.st_dokumenta LIKE '{0}' ".format(st_dokumenta))
                    
                    if tipDokumenta == None:
                        pogoji.append(" dokument.tip LIKE '%' ")
                    else:
                        pogoji.append(" dokument.tip LIKE '{0}' ".format(tipDokumenta))
                    
                    if datumIzdajeDokument == None:
                        pogoji.append(" dokument.datum_izdaje LIKE '%' ")
                    else:
                        pogoji.append(" dokument.datum_izdaje {0} '{1}' ".format(datumIzdajeDokumentOP, datumIzdajeDokument))
                    
                    if datumPotekaDokument == None:
                        pogoji.append(" dokument.datum_poteka LIKE '%' ")
                    else:
                        pogoji.append(" dokument.datum_poteka LIKE '{0}' ".format(datumPotekaDokumentOP, datumPotekaDokument))
                    
                    if kraticaDrzave == None:
                        pogoji.append(" dokument.drzava LIKE '%' ")
                    else:
                        pogoji.append(" dokument.drzava IN {0} ".format(tuple(kraticaDrzave)))
                    
                    #Kar se tiče prestopa

                    if prestopID == None:
                        pogoji.append(" prestop.id LIKE '%' ")
                    else:
                        pogoji.append(" prestop.id LIKE '{0}' ".format(prestopID))
                    
                    if namen == None:
                        pogoji.append(" prestop.namen LIKE '%' ")
                    else:
                        pogoji.append(" prestop.namen LIKE '{0}' ".format(namen))
                    
                    if datumPrestopa == None:
                        pogoji.append(" prestop.datum LIKE '%' ")
                    else:
                        pogoji.append(" prestop.datum LIKE {0} '{1}' ".format(datumPrestopaOP, datumPrestopa))
                    
                    if mejniPrehod == None:
                        pogoji.append(" prestop.mejni_prehod LIKE '%' ")
                    else:
                        pogoji.append(" prestop.mejni_prehod LIKE {0} ".format(mejniPrehod))
                    

                    #Kar se tiče vize

                    if potrebnaViza:
                        if vizaID == None:
                            pogoji.append(" vizum.id LIKE '%' ")
                        else:
                            pogoji.append(" vizum.id LIKE '{0}' ".format(vizaID))
                        
                        if tipVize == None:
                            pogoji.append(" vizum.tip LIKE '%' ")
                        else:
                            pogoji.append(" vizum.tip LIKE '{0}' ".format(tipVize))
                        
                        if datumIzdajeViza == None:
                            pogoji.append(" vizum.datum_izdaje LIKE '%' ")
                        else:
                            pogoji.append(" vizum.datum_izdaje {0} '{1}' ".format(datumIzdajeVizaOP, datumIzdajeViza))
                        
                        if datumPotekaViza == None:
                            pogoji.append(" vizum.datum_poteka LIKE '%' ")
                        else:
                            pogoji.append(" vizum.datum_poteka {0} '{1}' ".format(datumPotekaVizaOP, datumPotekaViza))


                    sql += "AND".join(pogoji)
                    izvedi = con.execute(sql)
                    for x in izvedi:
                        osebe.append(x[0])
                    return set(osebe)

def izpisPodatkov(stevilka):
    """Prejme ID neke osebe in vrne podatke, ki jih želimo izpisati v uporabniškem vmesniku"""
    sql = """SELECT oseba.ime, oseba.priimek, oseba.spol, oseba.naslov, drzava.naziv, oseba.datum_rojstva, dokument.st_dokumenta
            FROM oseba JOIN dokument ON oseba.id = dokument.oseba JOIN drzava on dokument.drzava = drzava.kratica
            WHERE oseba.id = ? """
    izvedba = con.execute(sql, [stevilka])
    oseba = []
    for x in list(izvedba)[0]:
        oseba.append(x)
    return oseba
##############################################################################
def blackList():
    """Vrne vse tiste stevilke oseb, ki so v državi, ampak ne bi smeli biti """
    osebe = set()
    #Najprej preverimo tiste, ki so jim potekli dokumenti ali pa so lažni,
    #kar pomeni, da začnejo veljati šele po vstopu
    sql1 = """SELECT oseba.id
                FROM oseba
                    JOIN
                    dokument ON oseba.id = dokument.oseba
                    JOIN
                    prestop ON dokument.st_dokumenta = prestop.dokument
                WHERE dokument.datum_poteka < prestop.datum OR 
                    dokument.datum_izdaje > prestop.datum; """
    for st in con.execute(sql1):
        osebe.add(st[0])
    
    #Zdaj preverimo še tiste, ki nimajo veljavne vize 
    #bodi si jim je potekla pred dokumentom
    #ali pa jim je potekla ko so hoteli prestopiti

    sql2 = """ SELECT oseba.id
                FROM oseba
                    JOIN
                    dokument ON oseba.id = dokument.oseba
                    JOIN
                    vizum ON dokument.st_dokumenta = vizum.dokument
                    JOIN
                    prestop ON dokument.st_dokumenta = prestop.dokument
                WHERE vizum.datum_poteka < dokument.datum_poteka OR 
                    vizum.datum_izdaje > dokument.datum_izdaje OR 
                    vizum.datum_poteka < prestop.datum OR 
                    vizum.datum_izdaje > prestop.datum;"""
    for st in con.execute(sql2):
        osebe.add(st[0])
    
    return list(osebe)

########Funkcije za dodajanje v bazo################################################
def dodajOsebo(ime, priimek, spol, naslov = None, datum_rojstva = None):
  sql = "INSERT INTO oseba (ime, priimek, spol, naslov, datum_rojstva) VALUES (?, ?, ?, ?, ?)"
  con.execute(sql, (ime, priimek, spol, naslov, datum_rojstva))

def dodajDokument(st_dokumenta, oseba, tip, datum_izdaje, datum_poteka, drzava):
  vsiDokumenti = isciDokumente()
  if st_dokumenta in vsiDokumenti:
    raise Exception("Ta dokument je že v bazi podatkov!")
  elif datum_izdaje > datum_poteka:
    raise Exception("S tem dokumentom nekaj ni vredu!")
  else:
    sql = "INSERT INTO dokument (st_dokumenta, oseba, tip, datum_izdaje, datum_poteka, drzava) VALUES (?, ?, ?, ?, ?, ?)"
    con.execute(sql, (st_dokumenta, oseba, tip, datum_izdaje, datum_poteka, drzava))

def dodajVizum(dokument, tip, datum_izdaje, datum_poteka):
  vsiDokumenti = isciDokumente()
  if dokument not in vsiDokumenti:
    raise Exception("Brez dokumenta ne bo vize!")
  podatkiDokumenta = con.execute("SELECT dokument.datum_izdaje, dokument.datum_poteka FROM dokument WHERE dokument.st_dokumenta = ?", [dokument])
  datumiDok = [] #datum izdaje in datum poteka dokumenta
  datumiDok = list(podatkiDokumenta)
  dokIzdaja = datumiDok[0][0]
  dokPotek = datumiDok[0][1]

  if datum_izdaje < dokIzdaja and datum_izdaje < dokPotek and datum_poteka > dokIzdaja and datum_poteka > dokPotek:
    sql = "INSERT INTO vizum (dokument, tip, datum_izdaje, datum_poteka) VALUES (?, ?, ?, ?)"
    con.execute(sql, (dokument, tip, datum_izdaje, datum_poteka))
  else:
    raise Exception("Dokumenti niso veljavni!")

def dodajPrestop(dokument, namen, mejni_prehod, datum):
  vsiDokumenti = isciDokumente()
  if dokument not in vsiDokumenti:
    raise Exception("Dokument ne obstaja")
  
  podatkiDokumenta = con.execute("SELECT dokument.datum_izdaje, dokument.datum_poteka FROM dokument WHERE dokument.st_dokumenta = ?", [dokument])
  datumiDok = [] #datum izdaje in datum poteka dokumenta
  datumiDok = list(podatkiDokumenta)
  dokIzdaja = datumiDok[0][0]
  dokPotek = datumiDok[0][1]

  if datum < dokPotek:
    sql = "INSERT INTO prestop (dokument, namen, mejni_prehod, datum) VALUES (?, ?, ?, ?)"
    con.execute(sql, (dokument, namen, mejni_prehod, datum))
  else:
    raise Exception("Dokumenti niso veljavni!")

if __name__ == "__main__":
    cifre = isci_parametri(spol = "M", kraticaDrzave = ["SVN", "SWE", "FIN"])
    for x in cifre:
        print(izpisPodatkov(x))